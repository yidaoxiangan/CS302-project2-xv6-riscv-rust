use core::panic;
use crate::{fs, process};
use crate::consts::fs::{DIRSIZ, ROOTDEV, ROOTINO};

use super::Inode;
use super::inode::{iget, ilock};
use super::inode::idup;

pub fn namei(path: &[u8]) -> &mut Inode {
    let mut name: [u8; DIRSIZ] = [0; DIRSIZ];
    namex(path, false, &mut name)
}

// TODO
fn namex(path: &[u8], nameparent: bool, _name: &mut [u8]) -> &'static mut Inode {
    if path[0] != b'/' {
        panic!("namex: path={:?}, not start as root", path);
    }

    let mut ip = &mut fs::Inode::new();
    if path.len() == 1{
        ip = iget(ROOTDEV,ROOTINO);
    }else{
        let nowProc = &mut unsafe{process::CPU_MANAGER.my_proc()};
        let nowInode =  unsafe{&mut *nowProc.data.get_mut().get_cwd()};
        ip = idup(nowInode);
    }

    //todo while. now begin from 1:

    ilock(ip);

    // for i in 0..10 {
    //     print!("{:?}",path[i] as char);
    // }
    // panic!("chengshuaihan nanshen");

    if nameparent {
        panic!("namex: nameparent not supported yet");
    }

    let ip = iget(ROOTDEV, ROOTINO);
    
    ip
}