//! Inode-relevant operations

use core::cmp::min;

use array_macro::array;

use crate::consts::fs::BSIZE;
use crate::consts::fs::NDIRECT;
use crate::spinlock::SpinLock;
use crate::consts::fs::NINODE;
use super::BCACHE;
use super::Buf;
use super::Inode;
use super::LOG;
use super::bio;
use super::bio::Bcache;
use super::bio::balloc;
use super::bio::bmap;

static mut ICACHE: Icache = Icache::new();

struct Icache {
    lock: SpinLock<()>,
    inodes: [Inode; NINODE],
}

// Correspond to fs.c/struct itable.

impl Icache {
    const fn new() -> Self {
        Self {
            lock: SpinLock::new((), "icache"),
            inodes: array![_ => Inode::new(); NINODE],
        }
    }
}
/// Find the inode with number inum on device dev
/// and return the in-memory copy. Does not lock
/// the inode and does not read it from disk.
pub fn iget(dev: u32, inum: u32) -> &'static mut Inode {
    let icache = unsafe {ICACHE.lock.lock()};

    // Is the inode we are looking for already cached?
    let mut empty: Option<&mut Inode> = None;
    for ip in unsafe {ICACHE.inodes.iter_mut()} {
        if ip.iref > 0 && ip.dev == dev && ip.inum == inum {
            ip.iref += 1;
            drop(icache);
            return ip;
        }
        if empty.is_none() && ip.iref == 0 {
            empty = Some(ip);
        }
    }

    // Recycle an inode cacahe entry
    if empty.is_none() {
        panic!("iget: no enough space in inode cache");
    }
    let ip: &mut Inode = empty.take().unwrap();
    ip.dev = dev;
    ip.inum = inum;
    ip.iref = 1;
    ip.valid = false;
    drop(icache);
    ip
}

// Realize fs.c/readi()

// Read data from inode.
// Caller must hold ip->lock.
// If user_dst==1, then dst is a user virtual address;
// otherwise, dst is a kernel address.
pub fn readi(ip: & mut Inode, user_dst: i32, dst: u64, off: u32,n: u32) -> u32{
    let mut tot:u32 = 0;
    let mut m:u32;
    // let mut bp;

    let mut n = n;
    if off > ip.size.get() || off + n < off{
        return 0;
    }
    if off + n > ip.size.get(){
        n = ip.size.get() - off;
    }

    let mut dst = dst;
    let mut off = off;
    let mut bp ;
    loop{
    //     // TODO FINISHIT
        bp = BCACHE.bread(ip.dev, bmap(ip, off/(BSIZE as u32)));
        m = min(n - tot, BSIZE as u32 - off % BSIZE as u32);

        // if ()
       
        tot += m;
        dst += m as u64;
        off += m;

        if tot >= n {
            break;
        }
    }
    3
    
}



/// Lock the given inode.
/// Reads the inode from disk if necessary.
/// LTODO - do not lock the inode yet, only process zero exists
pub fn ilock(ip: &mut Inode) {
    if ip.iref < 1 {
        panic!("ilock: iref smaller than 1");
    }


    // acquire sleep lock

    if !ip.valid {
        // bp = bread(ip.dev, )
    }
}


pub fn idup(ip: &mut Inode) -> &mut Inode {

    // TODO acquire()
    // println!("my cupid: {}, now cpu id:{}",unsafe{ICACHE.lock.cpuid.get()},unsafe{CpuManager::cpu_id()});
    let icache = unsafe {ICACHE.lock.lock()};
    // println!("{}",ip.inum);
    // println!("22222");
    ip.iref += 1;
    drop(icache);
    ip
}