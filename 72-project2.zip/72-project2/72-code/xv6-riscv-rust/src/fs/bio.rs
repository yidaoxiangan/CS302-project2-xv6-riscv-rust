//! buffer cache layer

use array_macro::array;

use core::ptr;
use core::ops::{Deref, DerefMut};
use core::sync::atomic::{Ordering, AtomicBool};

use crate::sleeplock::{SleepLock, SleepLockGuard};
use crate::spinlock::SpinLock;
use crate::driver::virtio_disk::DISK;
use crate::consts::fs::{BPB, BSIZE, NBUF, NDIRECT};

use super::{Inode, LOG};
use super::superblock::{SUPER_BLOCK, SuperBlock};

pub static BCACHE: Bcache = Bcache::new();

pub struct Bcache {
    ctrl: SpinLock<BufLru>,
    bufs: [BufInner; NBUF],
}

impl Bcache {
    const fn new() -> Self {
        Self {
            ctrl: SpinLock::new(BufLru::new(), "BufLru"),
            bufs: array![_ => BufInner::new(); NBUF],
        }
    }

    /// Init the bcache.
    /// Should only be called once when the kernel inits itself.
    pub fn binit(&self) {
        let mut ctrl = self.ctrl.lock();
        let len = ctrl.inner.len();

        // init the head and tail of the lru list
        ctrl.head = &mut ctrl.inner[0];
        ctrl.tail = &mut ctrl.inner[len-1];

        // init prev and next field
        ctrl.inner[0].prev = ptr::null_mut();
        ctrl.inner[0].next = &mut ctrl.inner[1];
        ctrl.inner[len-1].prev = &mut ctrl.inner[len-2];
        ctrl.inner[len-1].next = ptr::null_mut();
        for i in 1..(len-1) {
            ctrl.inner[i].prev = &mut ctrl.inner[i-1];
            ctrl.inner[i].next = &mut ctrl.inner[i+1];
        }
        
        // init index
        ctrl.inner.iter_mut()
            .enumerate()
            .for_each(|(i, b)| b.index = i);
    }

    fn bget(&self, dev: u32, blockno: u32) -> Buf<'_> {
        let mut ctrl = self.ctrl.lock();

        // find cached block
        match ctrl.find_cached(dev, blockno) {
            Some((index, rc_ptr)) => {
                // found
                drop(ctrl);
                Buf {
                    index,
                    dev,
                    blockno,
                    rc_ptr,
                    data: Some(self.bufs[index].data.lock())
                }
            }
            None => {
                // not cached
                // recycle the least recently used (LRU) unused buffer
                match ctrl.recycle(dev, blockno) {
                    Some((index, rc_ptr)) => {
                        self.bufs[index].valid.store(false, Ordering::Relaxed);
                        drop(ctrl);
                        return Buf {
                            index,
                            dev,
                            blockno,
                            rc_ptr,
                            data: Some(self.bufs[index].data.lock()),
                        }
                    }
                    None => panic!("no usable buffer")
                }
            }
        }
    }

    /// Get the buf from the cache/disk
    pub fn bread<'a>(&'a self, dev: u32, blockno: u32) -> Buf<'a> {
        let mut b = self.bget(dev, blockno);
        if !self.bufs[b.index].valid.load(Ordering::Relaxed) {
            DISK.rw(&mut b, false);
            self.bufs[b.index].valid.store(true, Ordering::Relaxed);
        }
        b
    }

    /// Move an unlocked buf to the head of the most-recently-used list.
    fn brelse(&self, index: usize) {
        self.ctrl.lock().move_if_no_ref(index);
    }
}

/// A wrapper of raw buf data.
pub struct Buf<'a> {
    index: usize,
    dev: u32,
    blockno: u32,
    rc_ptr: *mut usize,     // pointer to its refcnt in BufCtrl
    /// Guaranteed to be Some during Buf's lifetime.
    /// Introduced to let the sleeplock guard drop before the whole struct.
    data: Option<SleepLockGuard<'a, BufData>>,
}

impl<'a> Buf<'a> {
    pub fn read_blockno(&self) -> u32 {
        self.blockno
    }

    pub fn bwrite(&mut self) {
        DISK.rw(self, true);
    }

    /// Gives out a raw const pointer at the buf data. 
    pub fn raw_data(&self) -> *const BufData {
        let guard = self.data.as_ref().unwrap();
        guard.deref()
    }

    /// Gives out a raw mut pointer at the buf data. 
    pub fn raw_data_mut(&mut self) -> *mut BufData {
        let guard = self.data.as_mut().unwrap();
        guard.deref_mut()
    }

    /// Pin the buf.
    /// SAFETY: it should be definitly safe.
    ///     Because the current refcnt >= 1, so the rc_ptr is valid.
    pub unsafe fn pin(&self) {
        let rc = *self.rc_ptr;
        *self.rc_ptr = rc + 1;
    }

    /// Unpin the buf.
    /// SAFETY: it should be called matching pin.
    pub unsafe fn unpin(&self) {
        let rc = *self.rc_ptr;
        if rc <= 1 {
            panic!("buf unpin not match");
        }
        *self.rc_ptr = rc - 1;
    }
}

impl<'a> Drop for Buf<'a> {
    fn drop(&mut self) {
        drop(self.data.take());
        BCACHE.brelse(self.index);        
    }
}

struct BufLru {
    inner: [BufCtrl; NBUF],
    head: *mut BufCtrl,
    tail: *mut BufCtrl,
}

/// Raw pointers are automatically thread-unsafe.
/// See doc https://doc.rust-lang.org/nomicon/send-and-sync.html.
unsafe impl Send for BufLru {}

impl BufLru {
    const fn new() -> Self {
        Self {
            inner: array![_ => BufCtrl::new(); NBUF],
            head: ptr::null_mut(),
            tail: ptr::null_mut(),
        }
    }

    /// Find if the requested block is cached.
    /// Return its index and incr the refcnt if found.
    fn find_cached(&mut self, dev: u32, blockno: u32) -> Option<(usize, *mut usize)> {
        let mut b = self.head;
        while !b.is_null() {
            let bref = unsafe { b.as_mut().unwrap() };
            if bref.dev == dev && bref.blockno == blockno {
                bref.refcnt += 1;
                return Some((bref.index, &mut bref.refcnt));
            }
            b = bref.next;
        }
        None
    }

    /// Recycle an unused buffer from the tail.
    /// Return its index if found.
    fn recycle(&mut self, dev: u32, blockno: u32) -> Option<(usize, *mut usize)> {
        let mut b = self.tail;
        while !b.is_null() {
            let bref = unsafe { b.as_mut().unwrap() };
            if bref.refcnt == 0 {
                bref.dev = dev;
                bref.blockno = blockno;
                bref.refcnt += 1;
                return Some((bref.index, &mut bref.refcnt));
            }
            b = bref.prev;
        }
        None
    }

    /// Move an entry to the head if no live ref.
    fn move_if_no_ref(&mut self, index: usize) {
        let b = &mut self.inner[index];
        b.refcnt -= 1;
        if b.refcnt == 0 && !ptr::eq(self.head, b) {
            // forward the tail if b is at the tail
            // b may be the only entry in the lru list
            if ptr::eq(self.tail, b) && !b.prev.is_null() {
                self.tail = b.prev;
            }
            
            // detach b
            unsafe {
                b.next.as_mut().map(|b_next| b_next.prev = b.prev);
                b.prev.as_mut().map(|b_prev| b_prev.next = b.next);
            }

            // attach b
            b.prev = ptr::null_mut();
            b.next = self.head;
            unsafe {
                self.head.as_mut().map(|old_head| old_head.prev = b);
            }
            self.head = b;
        }
    }
}

struct BufCtrl {
    dev: u32,
    blockno: u32,
    prev: *mut BufCtrl,
    next: *mut BufCtrl,
    refcnt: usize,
    index: usize,
}

impl BufCtrl {
    const fn new() -> Self {
        Self {
            dev: 0,
            blockno: 0,
            prev: ptr::null_mut(),
            next: ptr::null_mut(),
            refcnt: 0,
            index: 0,
        }
    }
}

struct BufInner {
    // valid is guarded by
    // the bcache spinlock and the relevant buf sleeplock
    // holding either of which can get access to them
    valid: AtomicBool,
    data: SleepLock<BufData>,
}

impl BufInner {
    const fn new() -> Self {
        Self {
            valid: AtomicBool::new(false),
            data: SleepLock::new(BufData::new(), "BufData"),
        }
    }
}

/// Alignment of BufData should suffice for other structs
/// that might converts from this struct.
#[repr(C, align(8))]
pub struct BufData(pub [u8; BSIZE]);

impl  BufData {
    const fn new() -> Self {
        Self([0; BSIZE])
    }
}

// Allocate a block to a inode by the dev number of inode.
pub fn balloc(dev: u32) ->  u32 {
    let mut b:i32 = 0;
    let mut bi:i32;
    let m: i32;

    let mut bp: Buf;

    let SB_SIZE = unsafe { SUPER_BLOCK.size() as i32};

    while b < SB_SIZE {

        let B_BLOCK :u32 = unsafe {(b as u32 / BPB as u32 + SUPER_BLOCK.bmapstart()) as u32};

        bp = BCACHE.bread(dev,B_BLOCK);

        bi = 0;
        while bi < BPB as i32 && b + bi < SB_SIZE {
            let m = 1 << (bi % 8);
            if unsafe {((*bp.raw_data()).0)[(bi / 8) as usize] & m } == 0 {
                unsafe {((*bp.raw_data_mut()).0)[(bi / 8) as usize] |= m };
                let index = bp.index;
                LOG.write(bp);
                BCACHE.brelse(index);
                bzero(dev as i32, b + bi);

                return (b + bi) as u32;
            }

            bi += 1;
        }

        BCACHE.brelse(bp.index);
        b += BPB as i32;
    }

    panic!("balloc: out of blocks");

}
    
pub fn bzero(dev: i32, bno: i32){

    let mut buf = BCACHE.bread(dev as u32,bno as u32);
    let index = buf.index;
    let mut bp  = unsafe {(*(buf.raw_data_mut())).0 };
    let len = bp.len();

    for i in & mut bp[0..len] {*i = 0}
    
    BCACHE.brelse(index);
}

pub fn bfree (dev: i32, b: u32){
    let bi: i32;
    let m: i32;

    let B_BLOCK :u32 = unsafe {(b as u32 / BPB as u32 + SUPER_BLOCK.bmapstart()) as u32};
    let mut bp = BCACHE.bread(dev as u32, B_BLOCK);

    bi = (b as i32) % BPB as i32;

    m = 1 << (bi % 8);

    if unsafe {((*bp.raw_data()).0)[(bi / 8) as usize] == 0} {
        panic!("freeing free block");
    }

    unsafe {((*bp.raw_data_mut()).0)[(bi / 8) as usize] &= (!m) as u8;}
    let index = bp.index;
    LOG.write(bp);
    BCACHE.brelse(index);

}

pub fn bmap(ip: &mut Inode, bn: u32) -> u32{
    let mut addr: u32 = 0;
    let mut bp: Buf;

    if bn < NDIRECT as u32 {
        addr = ip.addrs.get()[bn as usize];
            if addr == 0 {
                addr = balloc(ip.dev);
                ip.addrs.get_mut()[NDIRECT as usize] = addr;
                return addr;
            }
        } 
        bp = BCACHE.bread(ip.dev,addr);
        
        let a =  bp.raw_data_mut();

        addr = unsafe {((*a).0)[bn as usize] as u32};
        
        let mut index: usize = 0; 
        if addr == 0 {
            addr = balloc(ip.dev);
            unsafe {((*a).0)[bn as usize] = addr as u8}

            index = bp.index;
            LOG.write(bp);
        }

        BCACHE.brelse(index);
        addr
    }