use core::mem;
use core::ptr;
use crate::printf;

use crate::fs::inode::{idup,ilock};
use crate::consts::NOFILE;
use crate::consts::{MAXPATH};
use crate::consts::{MAXARG};
use crate::fs::Inode;
use crate::process;
use crate::process::CPU_MANAGER;
use crate::process::PROC_MANAGER;
use crate::process::proc::ProcState;
use super::proc::Proc;


pub trait Syscall {
    fn sys_fork(&mut self) -> usize;
    fn sys_read(&mut self) -> usize;
    fn sys_exec(&mut self) -> usize;
}
pub static mut count: usize = 0;

impl Syscall for Proc {
    fn sys_read(&mut self) -> usize{
        0
    }
    fn sys_fork(&mut self) -> usize{
        // Allocate process.
        let np = unsafe{PROC_MANAGER.alloc_proc()};
        match np{
            Some(np) => {
                let newPageTable = np.data.get_mut().get_pagetable();
                let mut sz = self.data.get_mut().get_sz();
                self.data.get_mut().get_pagetable().uvm_copy(newPageTable, sz);

                np.data.get_mut().set_sz(self.data.get_mut().get_sz().clone());

                // copy saved user registers.
                np.data.get_mut().set_tf(self.data.get_mut().get_tf().clone());

                // Cause fork to return 0 in the child.
                unsafe{&mut *np.data.get_mut().get_tf()}.a0 = 0;

                // increment reference counts on open file descriptors.
                //TODO it don't have file reference counts
                // for i in 0..NOFILE{
                //     if 
                // }

                // TODO error in spinlock
                let p_cwd = unsafe{&mut *self.data.get_mut().get_cwd()};
                np.data.get_mut().set_cwd(idup(p_cwd));

                np.data.get_mut().set_name(self.data.get_mut().get_name().clone());

                let mut p_excl = self.excl.lock();
                let mut np_excl = np.excl.lock();

                (*p_excl).pid = (*np_excl).pid;
                (*np_excl).state = ProcState::RUNNABLE;

                drop(&np.excl);
                drop(&p_excl);
                
                unsafe{count = unsafe{count} + 1};
                println!("Fork finish, counts: {}",unsafe{count});
            }
            None => {
                panic!("Can not fork: not alloc new process");
            }
        }

        // Copy user memory from parent to child.
        // if 

        // panic!("sys_fork: end");
        1
    }

    fn sys_exec(&mut self) -> usize {
        // TODO - UB here
        let mut path: [u8; MAXPATH] = unsafe {
            mem::MaybeUninit::uninit().assume_init()
        };

        match self.arg_str(0, &mut path) {
            Ok(_) => {
                // debug
                print!("Get in OK() \n");
                print!("sys_exec: ");
                for c in path.iter() {
                    if *c == 0 {
                        break
                    }
                    print!("{}", *c as char);
                }
                println!();
            }
            Err(str) => {
                println!("sys_exec1: {}", str);
                return usize::MAX;
            }
        }
        


        // tmp ignore argv, i.e., only have path as first argument
        // also not copy any content from user to kernel

        // Add arg. It is a pointr array.
        // let mut argv: [*mut u8; MAXARG] = [ptr::null_mut(); MAXARG];

        // let argv_addr: *const usize = self.arg_addr(1);

        // match self.fetch_str(argv_addr, &mut argv[0]) {
            // Ok(_) => {
                // print! ("fetch str OK");
            // }
            // Err(_) => {}
        // }
        // argv[0] = unsafe {*argv_addr} as *mut u8;
        // argv[1] = unsafe {*argv_addr.offset(1)} as *mut u8;

        // if argv[1] as usize != 0 {
        //     panic!("argv[1] is not 0, is {}...", unsafe {*argv[1]});
        // }
        // argv[1] = ptr::null_mut();

        // TODO - ELF load
        // tmp ignore argv, i.e., only have path as first argument
        // also not copy any content from user to kernel
        let mut argv: [u8; MAXARG] = unsafe {
            mem::MaybeUninit::uninit().assume_init()
        };
        // let argv_addr= self.arg_addr(1);
        // let tf = unsafe { &mut *self.data.get_mut().get_tf() };
        // println!("::::{}",unsafe{*argv_addr});
        for i in 1..5{
            argv[i] = self.arg_addr(i) as u8;
        }
        // argv[0] = unsafe {*argv_addr} as u8;
        // argv[1] = unsafe {*argv_addr.offset(1)} as u8;
        // if argv[1] as usize != 0 {
        //     panic!("argv[1] is not 0, is {}...", unsafe {*argv[1]});
        // }
        // argv[1] = ptr::null_mut();

        // TODO - ELF load
        // let p = unsafe{CPU_MANAGER.my_proc()};
        // println!("{}",path[0] as char);
        process::elf::load(self,&path);
        panic!("sys_exec: end");
    }
}
