// System call numbers
#define SYS_fork    1
#define SYS_fork    5
#define SYS_exec    7
