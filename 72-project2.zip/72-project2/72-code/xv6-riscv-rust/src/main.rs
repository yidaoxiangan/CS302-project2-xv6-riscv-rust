#![no_std]
#![no_main]

#[allow(unused_imports)]
use xv6_riscv_rust;
